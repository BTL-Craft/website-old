<!doctype html>
<html lang="zh">

<head>
    <meta charset="utf-8">
    <title>BTL Craft</title>
    <!-- 移动端 -->
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link href="/assets/style/index_.css" rel="stylesheet" type="text/css" />
    <link href="/assets/style/loading.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="assets/styles/css/styles.css" />
    <link rel="icon" type="img/png" href="/assets/image/icon.png" sizes="192x192" />
    <script src="/assets/script/jquery.js"></script>

    <script>
        window.onload = function() {
            $('#loading').fadeOut(150)
        }
    </script>
    <script>
        setInterval(() => {
            console.log($('.parent-container').scrollTop())
        }, 10);
    </script>
    
</head>

<body style="margin: 0; color: #fff;" id="body">
    <div id="loading">
        <div class="Sf-Kd mspin-medium">
            <div>
                <div></div>
            </div>
        </div>
    </div>
    <?php
    require '../app/get_video_data.php';
    ?>
    <div style="z-index: -10; display: flex; position: fixed; float: left; width: 100%; height: 100%; top: 0;background: linear-gradient(to top,#1e3c72,#2a5298);">
        <!-- <iframe src="/assets/background/index.html" frameborder="0" width="100%" title="background"></iframe> -->
    </div>
    <div class="top">
        <a href="." class="link">
            <p>BTL Craft</p>
        </a>
        <div class="icon">
            <div class="icon-icon" onclick="show_menu()">
                <span id="btn" class="icon menu"></span>
            </div>
        </div>
        <ul class="list">
            <li><a href="/user" class="a">用户中心</a></li>
            <li><a href="/help" class="a">获取帮助</a></li>
            <li><a href="https://btlcraft.top" class="a">皮肤站</a></li>
            <li><a href="/auth" class="a"><i class="icon"></i> 登录</a></li>
        </ul>
        <div class="menu" id="menu">
            <ul class="menu">
                <li><a href="/user" class="a">用户中心</a></li>
                <li><a href="/help" class="a">获取帮助</a></li>
                <li><a href="https://btlcraft.top" class="a">皮肤站</a></li>
                <li><a href="/auth" class="a"><i class="icon"></i> 登录</a></li>
            </ul>
        </div>
    </div>
    <div class="parent-container">
        <div class="pg pg0">
            <div class="splash">
                <p>BTL Craft</p>
                <a href="#about">了解更多</a>
            </div>
        </div>
        <div class="pg pg1" id="about">
            <div class="box1">
                <div class="text">
                    <h1>简单介绍</h1>
                    <?php
                    $startdate = "2022-03-01";
                    $now = new DateTime();
                    $now_ = $now->format("Y-m-d");
                    $second = strtotime($now_) - strtotime($startdate);
                    $day = $second / 86400;
                    echo "<p>BTL Craft成立与2022年3月1日，今天是开服的第{$day}天。这是一个原版技术向生存服务器（生电服），这里还有创造服、镜像服，这绝对是一个创造奇迹的好地方！</p>";
                    ?>
                </div>
            </div>
            <div class="box2">
                <div class="container">
                    <div class="item active" style="background-image: url(/assets/image/2022-08-25_23.03.15.jpg);">
                        <div class="shadow"></div>
                        <div class="content">
                            <div class="text">
                                <div class="tit">湖边小筑</div>
                                <div class="sub">某坏司机的家</div>
                            </div>
                        </div>
                    </div>
                    <div class="item" style="background-image: url(/assets/image/2022-08-25_23.08.52.jpg);">
                        <div class="shadow"></div>
                        <div class="content">
                            <div class="text">
                                <div class="tit">主基地</div>
                                <div class="sub">梦开始的地方</div>
                            </div>
                        </div>
                    </div>
                    <div class="item" style="background-image: url(/assets/image/2022-08-25_23.09.53.jpg);">
                        <div class="shadow"></div>
                        <div class="content">
                            <div class="text">
                                <div class="tit">工业区</div>
                                <div class="sub">迈向工业化！</div>
                            </div>
                        </div>
                    </div>
                    <div class="item" style="background-image: url(/assets/image/2022-08-25_23.12.31.jpg);">
                        <div class="shadow"></div>
                        <div class="content">
                            <div class="text">
                                <div class="tit">牛子园</div>
                                <div class="sub">懂的都懂</div>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    // 获取所有.item元素
                    let items = document.querySelectorAll('.item');

                    // 设置选中态样式
                    function setActive() {
                        // 遍历所有.item元素，移出active样式
                        items.forEach((item) => {
                            item.classList.remove('active');
                        })
                        // 为当前选中项添加active样式
                        this.classList.add('active');
                    }
                    // 遍历所有.item元素，分别为其设置点击事件
                    items.forEach((item) => {
                        item.addEventListener('click', setActive);
                    })
                </script>
            </div>
        </div>
        <div class="pg pg2" id="pg2">
            <div class="container">
                <h1><span style="font-family: minecraft_ten;">BTL Craft</span><br>摸鱼生电服务器</h1>
                <div class="btn"><a href="https://jq.qq.com/?_wv=1027&k=WhyKhuf1" target="_blank">加入BTL Craft</a></div>
            </div>
        </div>
        <div class="pg pg3" id="pg3">
            <div class="container">
                <h1>内服风景</h1>
                <div class="child-container">
                    <div class="card">
                        <img src="/assets/image/2022-08-26_11.46.35.jpg" alt="">
                        <div class="text">
                            <h2><span>全区快</span>史莱姆农场</h2>
                            <p>全服最重要的粘液球生产基地</p>
                        </div>
                    </div>
                    <div class="card">
                        <img src="/assets/image/2022-08-26_13.05.43.jpg" alt="">
                        <div class="text">
                            <h2><span>碧落</span>基地</h2>
                            <p>一个美丽的小镇</p>
                        </div>
                    </div>
                    <div class="card">
                        <img src="/assets/image/2022-08-26_13.15.12.jpg" alt="">
                        <div class="text">
                            <h2><span>末地小厅</span></h2>
                            <p>末地的一个小建筑</p>
                        </div>
                    </div>
                </div>
                <div class="t1">
                    <div class="t2">
                        <a class="img" target="_blank" href="https://www.bilibili.com/video/BV1HY4y1h7F9?share_source=copy_web&vd_source=adf669c4f898730e1599e676abdd4c4c">
                            <div class="cover-img" id="img-1">
                            </div>
                            <div class="video-info">
                                <p class="video-title">三天时间造完刷冰机和鱼塔，还顺手搓了末地石农场</p>
                                <p class="video-data"><i class="play"></i><?php echo load_data(3, 1); ?></p>
                            </div>
                        </a>
                    </div>
                    <div class="t2">
                        <a class="img" target="_blank" href="https://www.bilibili.com/video/BV1TY41177ps?share_source=copy_web&vd_source=adf669c4f898730e1599e676abdd4c4c">
                            <div class="cover-img" id="img-2">
                            </div>
                            <div class="video-info">
                                <p class="video-title">又过了一周，服里发生了翻天覆地的变化</p>
                                <p class="video-title"><br></p>
                                <p class="video-data"><i class="play"></i><?php echo load_data(4, 1); ?></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="t1">
                    <div class="t2">
                        <a class="img" target="_blank" href="https://www.bilibili.com/video/BV1vZ4y1q7Nd?share_source=copy_web&vd_source=adf669c4f898730e1599e676abdd4c4c">
                            <div class="cover-img" id="img-3">
                            </div>
                            <div class="video-info">
                                <p class="video-title">【100天纪念预告】把生存玩成创造的纯生存世界</p>
                                <p class="video-data"><i class="play"></i><?php echo load_data(2, 1); ?></p>
                            </div>
                        </a>
                    </div>
                    <div class="t2">
                        <a class="img" target="_blank" href="https://www.bilibili.com/video/BV16g411Z71K?share_source=copy_web&vd_source=adf669c4f898730e1599e676abdd4c4c">
                            <div class="cover-img" id="img-4">
                            </div>
                            <div class="video-info">
                                <p class="video-title">「不过是搓了个岛罢了」</p>
                                <p class="video-title"><br></p>
                                <p class="video-data"><i class="play"></i><?php echo load_data(1, 1); ?></p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="pg pg4" id="pg4">
            <div class="container">
                <h1>相关链接</h1>
                <div class="h1">
                    <div class="h2">
                        <a href="https://jq.qq.com/?_wv=1027&k=WhyKhuf1" target="_blank" title="QQ群">
                            <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="link qq" href="skin.2k2k.top">
                                <path d="M21.395 15.035a39.548 39.548 0 0 0-.803-2.264l-1.079-2.695c.001-.032.014-.562.014-.836C19.526 4.632 17.351 0 12 0S4.474 4.632 4.474 9.241c0 .274.013.804.014.836l-1.08 2.695a38.97 38.97 0 0 0-.802 2.264c-1.021 3.283-.69 4.643-.438 4.673.54.065 2.103-2.472 2.103-2.472 0 1.469.756 3.387 2.394 4.771-.612.188-1.363.479-1.845.835-.434.32-.379.646-.301.778.343.578 5.883.369 7.482.189 1.6.18 7.14.389 7.483-.189.078-.132.132-.458-.301-.778-.483-.356-1.233-.646-1.846-.836 1.637-1.384 2.393-3.302 2.393-4.771 0 0 1.563 2.537 2.103 2.472.251-.03.581-1.39-.438-4.673zM12.662 4.846c.039-1.052.659-1.878 1.385-1.846s1.281.912 1.242 1.964c-.039 1.051-.659 1.878-1.385 1.846s-1.282-.912-1.242-1.964zM9.954 3c.725-.033 1.345.794 1.384 1.846.04 1.052-.517 1.931-1.242 1.963-.726.033-1.346-.794-1.385-1.845C8.672 3.912 9.228 3.033 9.954 3zM7.421 8.294c.194-.43 2.147-.908 4.566-.908h.026c2.418 0 4.372.479 4.566.908a.14.14 0 0 1 .014.061c0 .031-.01.059-.026.083-.163.238-2.333 1.416-4.553 1.416h-.026c-2.221 0-4.39-1.178-4.553-1.416a.136.136 0 0 1-.014-.144zm10.422 8.622c-.22 3.676-2.403 5.987-5.774 6.021h-.137c-3.37-.033-5.554-2.345-5.773-6.021-.081-1.35.001-2.496.147-3.43.318.063.638.122.958.176v3.506s1.658.334 3.318.103v-3.225c.488.027.96.04 1.406.034h.025c1.678.021 3.714-.204 5.683-.594.146.934.227 2.08.147 3.43zM10.48 5.804c.313-.041.542-.409.508-.825-.033-.415-.314-.72-.629-.679-.313.04-.541.409-.508.824.034.417.315.72.629.68zM14.479 5.156c.078.037.221.042.289-.146.035-.095.025-.165-.009-.214-.023-.033-.133-.118-.371-.176-.904-.22-1.341.384-1.405.499-.04.072-.012.176.056.227.067.051.139.037.179-.006.58-.628 1.21-.208 1.261-.184z" />
                            </svg>
                        </a>
                        <p class="h1-title">QQ群</p>
                        <p class="h1-text">这是BTL Craft的审核群，如果你想加入我们，请先加入审核群。</p>
                    </div>
                    <div class="h2">
                        <a href="https://space.bilibili.com/553786126" target="_blank" title="bilibili">
                            <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="link bilibili">
                                <path d="M17.813 4.653h.854c1.51.054 2.769.578 3.773 1.574 1.004.995 1.524 2.249 1.56 3.76v7.36c-.036 1.51-.556 2.769-1.56 3.773s-2.262 1.524-3.773 1.56H5.333c-1.51-.036-2.769-.556-3.773-1.56S.036 18.858 0 17.347v-7.36c.036-1.511.556-2.765 1.56-3.76 1.004-.996 2.262-1.52 3.773-1.574h.774l-1.174-1.12a1.234 1.234 0 0 1-.373-.906c0-.356.124-.658.373-.907l.027-.027c.267-.249.573-.373.92-.373.347 0 .653.124.92.373L9.653 4.44c.071.071.134.142.187.213h4.267a.836.836 0 0 1 .16-.213l2.853-2.747c.267-.249.573-.373.92-.373.347 0 .662.151.929.4.267.249.391.551.391.907 0 .355-.124.657-.373.906zM5.333 7.24c-.746.018-1.373.276-1.88.773-.506.498-.769 1.13-.786 1.894v7.52c.017.764.28 1.395.786 1.893.507.498 1.134.756 1.88.773h13.334c.746-.017 1.373-.275 1.88-.773.506-.498.769-1.129.786-1.893v-7.52c-.017-.765-.28-1.396-.786-1.894-.507-.497-1.134-.755-1.88-.773zM8 11.107c.373 0 .684.124.933.373.25.249.383.569.4.96v1.173c-.017.391-.15.711-.4.96-.249.25-.56.374-.933.374s-.684-.125-.933-.374c-.25-.249-.383-.569-.4-.96V12.44c0-.373.129-.689.386-.947.258-.257.574-.386.947-.386zm8 0c.373 0 .684.124.933.373.25.249.383.569.4.96v1.173c-.017.391-.15.711-.4.96-.249.25-.56.374-.933.374s-.684-.125-.933-.374c-.25-.249-.383-.569-.4-.96V12.44c.017-.391.15-.711.4-.96.249-.249.56-.373.933-.373Z" />
                            </svg>
                        </a>
                        <p class="h1-title">bilibili</p>
                        <p class="h1-text">这是BTL官方账号，会在这里发布有意思的视频，求三连！</p>
                    </div>
                    <div class="h2">
                        <a href="https://btlcraft.top" target="_blank" title="皮肤站">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="2 2 27.5 27.5" class="link blessing-skin">
                                <g id="Boutique">
                                    <path d="M27.764,10.764,22.87,8.316h0A3.014,3.014,0,0,0,21.528,8H17.049V7.14a2.668,2.668,0,0,0,.886-4.359,2.731,2.731,0,0,0-3.772,0A1,1,0,0,0,15.577,4.2a.667.667,0,0,1,.944.943.663.663,0,0,1-.472.2,1,1,0,0,0-1,1V8H10.472a3.022,3.022,0,0,0-1.342.316L4.236,10.764a2.005,2.005,0,0,0-1.067,2.181l.69,3.447A2,2,0,0,0,5.82,18H8V28a2,2,0,0,0,2,2H22a2,2,0,0,0,2-2V18h2.18a2,2,0,0,0,1.961-1.607l.69-3.448A2.005,2.005,0,0,0,27.764,10.764ZM18.218,10a2.96,2.96,0,0,1-4.436,0Zm7.962,6H23a1,1,0,0,0-1,1V28H10V17a1,1,0,0,0-1-1H5.82l-.69-3.447,4.894-2.448A1.027,1.027,0,0,1,10.472,10h.96a4.978,4.978,0,0,0,9.136,0h.96a1.027,1.027,0,0,1,.448.105l4.894,2.448Z" />
                                </g>
                            </svg>
                        </a>
                        <p class="h1-title">皮肤站</p>
                        <p class="h1-text">Blessing Skin 提供 Minecraft 角色皮肤的上传以及托管服务。</p>
                    </div>
                </div>
                <h1>回声洞</h1>
                <div class="b1" onclick="hole()" id="hole-div">
                    <p id="hole">反复点击这里可以查看BTL成员乱七八糟的留言</p>
                </div>
            </div>
        </div>
        <div class="pg pg5">
            <p class="p1">
                Copyright © 2022
                <a href="/">BTL Craft</a>.
                保留所有权利
            </p>
            <p class="p2">
                友情链接：
                <a href="http://www.recraft.top" target="_blank">IEE服务器官网
                </a>
            </p>
        </div>
    </div>
    <script src="/assets/script/top.js"></script>
    <script src="/assets/script/anti-ie.js"></script>
    <script src="/assets/script/0cd1.js"></script>
    <script src="/assets/script/0cd2.js"></script>
    <script src="/assets/script/hole.js"></script>
    <script>
        if (navigator.userAgent.indexOf('Firefox') != -1) {
            alert('警告：由于火狐浏览器自身问题，使用火狐浏览器会导致错位，我们可能会在下一个版本中修复')
        }
    </script>
    <script>
        console.log(` ________   _________   ___               ________   ________   ________   ________  _________    `);
        console.log(`|\\   __  \\ |\___   ___\\|\\  \\             |\\   ____\\ |\\   __  \\ |\\   __  \\ |\\  _____\\|\\___   ___\\  `);
        console.log(`\\ \\  \\|\\ /_\\|___ \\  \\_|\\ \\  \\            \\ \\  \\___| \\ \\  \\|\\  \\\\ \\  \\|\\  \\\\ \\  \\__/ \\|___ \\  \\_|  `);
        console.log(` \\ \\   __  \\    \\ \\  \\  \\ \\  \\            \\ \\  \\     \\ \\   _  _\\\\ \\   __  \\\\ \\   __\\     \\ \\  \\   `);
        console.log(`  \\ \\  \\|\\  \\    \\ \\  \\  \\ \\  \\____        \\ \\  \\____ \\ \\  \\\\  \\|\\ \\  \\ \\  \\\\ \\  \\_|      \\ \\  \\  `);
        console.log(`   \\ \\_______\\    \\ \\__\\  \\ \\_______\\       \\ \\_______\\\\ \\__\\\\ _\\ \\ \\__\\ \\__\\\\ \\__\\        \\ \\__\\ `);
        console.log(`    \\|_______|     \\|__|   \\|_______|        \\|_______| \\|__|\\|__| \\|__|\\|__| \\|__|         \\|__| `);
        console.log(`                                                                                                                        `);
        console.log(`                                                                  Release 1.2.2. Powered by xxll-core 1.2.2`);
    </script>
    <script src="/assets/script/index.js"></script>
</body>

</html>