function show_menu() {
    if ($('#btn').attr('class') == 'icon menu')
    {
        $('.icon-icon').attr('style','pointer-events: none;')
        $('#btn').fadeOut(100)
        setTimeout(() => {
            $('#btn').attr('class','icon xmark')
            
            $('.icon-icon').attr('style','pointer-events: auto;')
        }, 100); 
        $('#menu').fadeIn(100)
        $('#btn').fadeIn(100)
    } else
    {
        $('.icon-icon').attr('style','pointer-events: none;')
        $('#btn').fadeOut(100)
        setTimeout(() => {
            $('#btn').attr('class','icon menu')
            $('.icon-icon').attr('style','pointer-events: auto;')
        }, 100); 
        $('#menu').fadeOut(100)
        $('#btn').fadeIn(100)
    }
}