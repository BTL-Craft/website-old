<?php
if (!array_key_exists('url',$_GET))
{
        require '../html/index.php';
} 
else 
{
    switch ($_GET['url']) 
    {
        case 'auth':
            require '../html/auth.php';
            break;

        case 'hole':
            require '../html/hole.php';
            break;

        case 'anti-ie':
            require '../html/anti-ie.php';
            break;
            
        default:
            if(substr($_GET['url'],0,4) == 'help')
            {
                $url = substr(strchr($_GET['url'],'/'),1);
                require '../html/help.php';  
            } 
            else
            {
                require '../html/404.php';
            }
    }
}

if (array_key_exists('key',$_GET) && $_GET['key'] == '777') 
{
    require '../app/clear.php';
}



