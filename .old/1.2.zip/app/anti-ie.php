<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>沉痛悼念Internet Explorer</title>
    <style>
        body {
            background-color: #cbdcf7;
            display: flex;
        }
        * {
            font-family: 微软雅黑;
            color: #2c6fdb;
        }
    </style>
</head>
<body>
    <p style="width: 100%;text-align: center;font-size: 30px;font-weight: 700;margin-top: 100px">不要使用ie！请使用Chrome等现代浏览器</p>
</body>
</html>