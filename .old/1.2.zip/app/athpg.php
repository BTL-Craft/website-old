<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <title id="title">登录 - BTL Craft</title>
    <link rel="stylesheet" href="/assets/style/auth.css">
    <!--     <script src="https://www.recaptcha.net/recaptcha/api.js" async defer></script>
 -->
    <script src="/assets/script/jquery.js"></script>
    <link rel="icon" type="img/png" href="/assets/image/icon.png" sizes="192x192"/>
</head>

<body>
    <div class=main>
        <p class="title"><a href="/" class="title">BTL Craft</a></p>
        <div class="wrapper" id="main">
            <div class="login" id="log">
                <form onsubmit="return false;">
                    <div class="input-data">
                        <input type="text" id="l-email" required />
                        <div class="underline"></div>
                        <label>Email</label>
                    </div>
                    <div class="input-data" style="margin: 25px 0">
                        <input type="password" id="l-password" required />
                        <div class="underline"></div>
                        <label>密码</label>
                    </div>
                    <div class="input-box">
                        <label>
                            <input type="checkbox" name="remem">
                            <span class="yes"></span><span style="margin-left: 5px;">记住我</span>
                        </label>
                    </div>
                    <button class="btn" id="l-alert" type="submit" onclick="login()"><span id="l-msg">登录</span></button>
                </form>
                <button class="bt forget" onclick="forget_page()">忘记密码</button>
                <button class="bt" id="i" onclick="reg_page()">注册新账号 <i class="icon reg"></i></button>
                <!--  <div id="alert" style="height: 0; padding: 0; border: 0;"><span id="msg"></span></div> -->
            </div>
            <div class="register" id="reg">
                <p style="margin-bottom: 10px; margin-top: -5px"><button class="back" onclick="log_page()"><i class="icon back"></i>返回</button></p>
                <form onsubmit="return false;">
                    <div class="input-data">
                        <input type="text" id="r-email" required />
                        <div class="underline"></div>
                        <label>电子邮箱</label>
                    </div>
                    <div class="input-data" style="margin-top: 25px">
                        <input type="password" id="r-password" required />
                        <div class="underline"></div>
                        <label>密码</label>
                    </div>
                    <div class="input-data" style="margin: 25px 0">
                        <input type="password" id="r-repassword" required />
                        <div class="underline"></div>
                        <label>重复密码</label>
                    </div>
                    <div class="input-data" style="margin:0">
                        <input type="text" id="r-username" required />
                        <div class="underline"></div>
                        <label>进服后要使用的玩家名</label>
                    </div>
                    <button class="btn" id="r-alert" onclick="register()" type="submit">
                        <span id="r-msg">注册</span>
                    </button>
                </form>
            </div>
            <div class="forget" id="forg">
                <p class="tip">输入你注册时填写的电子邮箱并点击发送</p>
                <form onsubmit="return false;">
                    <div class="input-data">
                        <input type="text" id="r-email" required />
                        <div class="underline"></div>
                        <label>电子邮箱</label>
                    </div>
                    <button type="submit" class="btn">发送</button>
                </form>
                <button class="bt" onclick="login_page()">我又想起来了</button>
            </div>
        </div>
    </div>
    <script src="/assets/script/auth.js"></script>
    <?php
    if (array_key_exists('reg', $_COOKIE)) {
        echo '<script>document.getElementById("i").setAttribute("style", "color: #828282; pointer-events: none");</script>';
    }
    ?>
</body>

</html>