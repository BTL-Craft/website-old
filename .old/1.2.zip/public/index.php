<?php
if (!array_key_exists('url',$_GET))
{
    if (array_key_exists('type',$_POST))
    {
        switch ($_POST['type'])
        {
            case 'login':
                require '../app/login.php';
        }
    } 
    else 
    {
        require '../app/index.php';
    }
} 
else 
{
    switch ($_GET['url']) 
    {
        case 'auth':
            require '../app/athpg.php';
            break;

        case 'hole':
            require '../app/contribution.php';
            break;

        case 'anti-ie':
            require '../app/anti-ie.php';
            break;
            
        default:
            if(substr($_GET['url'],0,4) == 'help')
            {
                $url = substr(strchr($_GET['url'],'/'),1);
                require '../app/help.php';  
            } 
            else
            {
                require '../app/404.php';
            }
    }
}

if (array_key_exists('key',$_GET) && $_GET['key'] == '777') 
{
    require '../app/clear.php';
}



