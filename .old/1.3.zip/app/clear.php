<?php
$config = json_decode(file_get_contents("../conf/mysql.json"), true); 
$servername = $config['servername'];
$dbname = $config['dbname'];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $config['username'], $config['password']);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $command = $conn->prepare("TRUNCATE TABLE usr");  
    $command->execute();
    $loginfo = '[' . date("H:i:s") .'] [MySQL/INFO]: Cleared table: usr' . "\n";
    fwrite(fopen('../log/'.date("Y-m-d").'.log', 'a'), $loginfo);
}
catch(PDOException $e)
{
    $errinfo = '[' . date("H:i:s") .'] [MySQL/ERROR]: '. $e->getMessage() . "\n";
    fwrite(fopen('../log/'.date("Y-m-d").'.log', 'a'), $errinfo);
}