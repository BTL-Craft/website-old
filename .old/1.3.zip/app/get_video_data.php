<?php
function load_data($id, $type)
{
    $data = json_decode(file_get_contents('https://api.bilibili.com/x/space/arc/search?mid=553786126'), true);
    if ($type == 1)
    {
        $data = $data['data']['list']['vlist'][$id]['play'];
        return ' '.$data;
    }
    if ($type == 2)
    {
        $data = $data['data']['list']['vlist'][$id]['video_review'];
        return ' '.$data;
    }
}
?>
