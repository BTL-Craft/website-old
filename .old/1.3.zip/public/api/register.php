<?php
if (file_exists('../../app/auth.php')) {
    require '../../app/auth.php';
}
else {
    echo '<script>alert("注册失败：关键文件缺失。\n请及时报告此问题，报告问题时附带上这个窗口的截图。\n错误发生时间："+Date());window.location.replace(".")</script>';
    $errinfo = '[' . date("H:i:s") .'] [register/ERROR]: The file was not found: auth.php' . "\n";
    fwrite(fopen('../../log/'.date("Y-m-d").'.log', 'a'), $errinfo);
}
if (!array_key_exists("email", $_POST) || !array_key_exists("password", $_POST) || !array_key_exists("username", $_POST)) 
{
    header('Location: .');
}
$eml = $_POST['email'];
$passwd = $_POST['password'];
$usrname = $_POST['username'];
if (filter_var($eml, 274)) 
{ //验证，通过后开始注册
    if (!preg_match('/[^\w]/', $usrname))
    {
        $ip = getip();
        $reg_time = date("Y-m-d h:i:s");
        register($eml, $passwd, $usrname, $ip, $reg_time, '0', '0');
    } else echo '用户名格式错误';
} 
else 
{
    echo 'Email格式错误'; //不通过则返回
}

