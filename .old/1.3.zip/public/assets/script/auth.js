function reg_page() 
{
    document.getElementById("main").setAttribute("style", "height: 402px");
    document.getElementById("log").setAttribute("style", "opacity: 0; z-index: -1;");
    setTimeout(function()
    {
        document.getElementById("reg").setAttribute("style", "z-index: 1; opacity: 1; margin-left: 0;");
    }
    , 100)
}

function log_page() 
{
    document.getElementById("reg").setAttribute("style", "z-index:-1;");
    
    setTimeout(function()
    {
        document.getElementById("main").setAttribute("style", "");
        document.getElementById("log").setAttribute("style", "opacity: 1; z-index: 1;");
    }, 100)
}

function login() 
{
    var eml = document.getElementById('l-email').value;
    var passwd = document.getElementById('l-password').value;
    if (eml=="" || eml==" " || passwd=="" || passwd==" ") 
    {
        show_alert('l-alert','l-msg','请把上面的所有内容填写完整','登录','login()');
        return false;
    }
    document.getElementById("l-alert").setAttribute("style", "background-color:#568de5; pointer-events: none");
    document.getElementById("l-alert").setAttribute("onclick", "return false");
    document.getElementById("l-msg").innerHTML= '登录中';
    setTimeout(function(){
        $.post("/api/login.php", 
        {
            'email': eml,
            'password': passwd
        },
        function(data) {
            if (data=='登录成功') 
            {
                document.getElementById('l-alert').setAttribute("style", "background-color:#94c86b; pointer-events: none");
                document.getElementById('l-msg').innerHTML= data;
            } 
            else 
            {
                show_alert('l-alert','l-msg',data,'登录','login()');
            }
        }
        );
    },800)
}

function register() 
{
    var eml = document.getElementById('r-email').value;
    var passwd = document.getElementById('r-password').value;
    var repasswd = document.getElementById('r-repassword').value;
    var usrname = document.getElementById('r-username').value;
    document.getElementById("r-alert").setAttribute("style", "background-color:#568de5; pointer-events: none");
    if (eml == "" || eml == " " || passwd == "" || passwd == " " || repasswd == null || repasswd == " " || usrname == null || usrname == " ")
    {
        show_alert('r-alert','r-msg','请把上面的所有内容填写完整','注册','register()');
        return false;
    }
    else {
        setTimeout(function(){
            if (passwd != repasswd)
            {
                show_alert('r-alert','r-msg','密码和确认的密码不一样诶？','注册');
            } else if (passwd.length<8)
            {
                show_alert('r-alert','r-msg','密码应当不少于八位','注册');
            }
            else
            {
                $.post("/api/register.php", 
                {
                    'email': eml,
                    'password': passwd,
                    'username': usrname
                },
                function(data) {
                    if (data=='注册完成') 
                    {
                        document.getElementById('r-msg').innerHTML= '注册完成！';
                        setTimeout(function() 
                        {
                            log_page();
                            document.getElementById("i").setAttribute("style", "color: #828282; pointer-events: none");
                        },800);
                        document.cookie="reg=false;expires=Thu, 18 Dec 2032 12:00:00 GMT";
                        document.getElementById("l-email").setAttribute("value", eml);
                        document.getElementById("l-password").setAttribute("value", passwd);
                        setTimeout(() => {
                            document.getElementById("remem").checked = true;
                            setTimeout(() => {
                                login()
                            }, 600);
                        }, 1000);
                    } 
                    else 
                    {
                        show_alert('r-alert','r-msg',data,'注册','register()');
                    }
                }
                );
            }
        },800)
    }
}

function animation(id) {
    var btn=$(id);
    var time=50;
    for (let i = 0; i < 4; i++) {
        btn.animate({'margin-left':'5px'},time);
        btn.animate({'margin-left':'-5px'},time);
    }
    btn.animate({'margin-left':'0'},time);
}

function show_alert(id1,id2,msg,msg2,callback) {
    document.getElementById(id1).setAttribute("onclick", "return false");
    document.getElementById(id1).setAttribute("style", "background-color:#c00; pointer-events: none");
    document.getElementById(id2).innerHTML= msg;
    animation('#'+id1);
    setTimeout(function() {
        document.getElementById(id2).innerHTML= msg2;
        document.getElementById(id1).setAttribute("style", "background-color: #007bff; pointer-events: all");
        document.getElementById(id1).setAttribute("onclick", callback);
    },1500)
}
function forget_page() {
    document.getElementById("log").setAttribute("style", "opacity: 0; z-index: -1;");
    setTimeout(function()
    {
        document.getElementById("main").setAttribute("style", "height: 220px");
        document.getElementById("forg").setAttribute("style", "z-index: 1; opacity: 1; margin-top: 0;");
    }
    , 100)
}

function login_page() {
    document.getElementById("forg").setAttribute("style", "z-index:-1;");
    setTimeout(function()
    {
        document.getElementById("main").setAttribute("style", "");
        document.getElementById("log").setAttribute("style", "opacity: 1; z-index: 1;");
    }, 100)
}