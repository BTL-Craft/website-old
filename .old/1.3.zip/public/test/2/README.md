# myLogin

好看的登录页面

## Installation-安装

clone到本地即可

## Requirements-必要条件

浏览器

## Usage-用法

用vscode或者其他前端编辑器打开，

在login.html页面alt+B即可打开

或者右键->在浏览器中打开

## Authors and acknowledgment - 贡献者和感谢

BlueSgler

## License-开源协议

ISC