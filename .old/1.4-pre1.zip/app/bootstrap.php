<?php

if (array_key_exists('key', $_GET)) {
    require __DIR__.'/../app/debug/autoload.php';
    goto end;
}

switch ($_GET['url']) {
    case 'auth':
        require __DIR__.'/../view/auth.php';
        break;

    case 'hole':
        require __DIR__.'/../view/hole.php';
        break;

    case 'anti-ie':
        require __DIR__.'/../view/anti-ie.php';
        break;

    default:
        if (substr($_GET['url'], 0, 4) == 'help') {
            $url = substr(strchr($_GET['url'], '/'), 1);
            require __DIR__.'/../view/help.php';
        } else {
            require __DIR__.'/../view/404.php';
        }
}

end: