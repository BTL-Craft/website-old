
<?php
/*
|--------------------------------------------------------------------------
| 注册自动加载程序
|--------------------------------------------------------------------------
|
| 引入 Composer 自动加载器
|
*/

require __DIR__.'/../vendor/autoload.php';

/*
|--------------------------------------------------------------------------
| 环境检查
|--------------------------------------------------------------------------
*/

if (file_exists(__DIR__.'/../storage/install.lock')) {
    require __DIR__.'/../app/chkenv.php';
}


if (array_key_exists('key', $_GET)) {
    require __DIR__.'/../app/bootstrap.php';
    goto end;
}


if (!array_key_exists('url', $_GET)) {
    require __DIR__.'/../view/index.php';
} else {
    require __DIR__.'/../app/bootstrap.php';
}



end:
