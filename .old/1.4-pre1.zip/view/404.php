<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="icon" type="img/png" href="/assets/image/icon.png" sizes="192x192" />
    <script src="/assets/script/jquery.js"></script>
    <link href="/assets/style/loading.css" rel="stylesheet" type="text/css" />
    <title>404 Not Found</title>
    <link rel="stylesheet" href="/assets/style/404.css">
</head>

<body>
    <div>
        <p class="title"><a href="/">BTL Craft</a></p>
        <p style="margin-top: 15vh;color: inherit;font-weight: 500;line-height: 1.2;margin-bottom: 0.5em;font-size: 1.4rem;">404 Not Found</p>
        <p style="margin: 0 0 1.2rem;">这里什么都没有哦</p>
    </div>
</body>

</html>