## BTL Craft官网

[![License](https://img.shields.io/github/license/Rene8028/carpet-iee-addition.svg)](https://www.gnu.org/licenses/quick-guide-gplv3.html)

如果你需要使用此项目，请前往release下载或手动构建，并在相关文件中改成自己的服务器名称。以后可能会做一个安装界面（咕~）。

## 手动构建
确保你已经安装composer，然后运行build.bat
  
## 使用早期版本
以前的版本都在.old文件夹下，直接下载下来并解压即可
