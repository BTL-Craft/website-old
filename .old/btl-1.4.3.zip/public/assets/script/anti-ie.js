if(!!window.ActiveXObject || "ActiveXObject" in window)
{
    window.location="/anti-ie";
}
