<?php

namespace App\Http\Controllers;

use Illuminate\Support\Arr;

class HomeController extends Controller
{
    public function index()
    {
        return view('index')
        ->with('site_name', 'BTL Craft');
    }

    public function apiRoot()
    {


    }
}
