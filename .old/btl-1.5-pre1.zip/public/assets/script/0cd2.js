VanillaTilt.init(document.querySelectorAll(".h2"),{
    max: 15,  
    speed: 400,  
    glare: false,  
})
