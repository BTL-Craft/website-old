<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /shared/navbar.twig */
class __TwigTemplate_4994d4c0e677da40859df91658f3f0b1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        echo "<div class=\"navbar\">
  <div>
    <div class=\"icon sdb\">
      <div class=\"icon-icon sdb\" onclick=\"sidebar()\">
        <span id=\"sdb-btn\" class=\"icon sidebar\"></span>
      </div>
    </div>
    <a href=\"/\" class=\"link\"><p>";
        // line 8
        echo twig_escape_filter($this->env, ($context["site_name"] ?? null), "html", null, true);
        echo "</p></a>
    <div class=\"icon\">
      <div class=\"icon-icon mnu\" onclick=\"menu()\">
        <span id=\"mnu-btn\" class=\"icon menu\"></span>
      </div>
    </div>
    <ul class=\"list\">
      <li>
        <a href=\"/join\" class=\"a\">加入我们</a>
      </li>
      <li>
        <a href=\"/help\" class=\"a\">获取帮助</a>
      </li>
      <li>
        <a href=\"https://btlcraft.top\" class=\"a\">皮肤站</a>
      </li>
      <li>
        <a href=\"/auth\" class=\"a\"><i class=\"icon\"></i> 登录</a>
      </li>
    </ul>
    <div class=\"menu\" id=\"menu\">
      <ul class=\"menu\">
        <li id=\"menu-li-1\">
          <a href=\"/join\" class=\"a\">加入我们</a>
        </li>
        <li id=\"menu-li-2\">
          <a href=\"/help\" class=\"a\">获取帮助</a>
        </li>
        <li id=\"menu-li-3\">
          <a href=\"https://btlcraft.top\" class=\"a\">皮肤站</a>
        </li>
        <li id=\"menu-li-4\">
          <a href=\"/auth\" class=\"a\"><i class=\"icon\"></i> 登录</a>
        </li>
      </ul>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "/shared/navbar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 8,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"navbar\">
  <div>
    <div class=\"icon sdb\">
      <div class=\"icon-icon sdb\" onclick=\"sidebar()\">
        <span id=\"sdb-btn\" class=\"icon sidebar\"></span>
      </div>
    </div>
    <a href=\"/\" class=\"link\"><p>{{ site_name }}</p></a>
    <div class=\"icon\">
      <div class=\"icon-icon mnu\" onclick=\"menu()\">
        <span id=\"mnu-btn\" class=\"icon menu\"></span>
      </div>
    </div>
    <ul class=\"list\">
      <li>
        <a href=\"/join\" class=\"a\">加入我们</a>
      </li>
      <li>
        <a href=\"/help\" class=\"a\">获取帮助</a>
      </li>
      <li>
        <a href=\"https://btlcraft.top\" class=\"a\">皮肤站</a>
      </li>
      <li>
        <a href=\"/auth\" class=\"a\"><i class=\"icon\"></i> 登录</a>
      </li>
    </ul>
    <div class=\"menu\" id=\"menu\">
      <ul class=\"menu\">
        <li id=\"menu-li-1\">
          <a href=\"/join\" class=\"a\">加入我们</a>
        </li>
        <li id=\"menu-li-2\">
          <a href=\"/help\" class=\"a\">获取帮助</a>
        </li>
        <li id=\"menu-li-3\">
          <a href=\"https://btlcraft.top\" class=\"a\">皮肤站</a>
        </li>
        <li id=\"menu-li-4\">
          <a href=\"/auth\" class=\"a\"><i class=\"icon\"></i> 登录</a>
        </li>
      </ul>
    </div>
  </div>
</div>
", "/shared/navbar.twig", "Y:\\www\\website\\resources\\views//shared/navbar.twig");
    }
}
