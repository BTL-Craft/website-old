<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Y:\www\website\resources\views/auth.twig */
class __TwigTemplate_63c9a4044338bf8bbcda85fe7b564d98 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\" />
    <title id=\"title\">登录 - ";
        // line 6
        echo twig_escape_filter($this->env, ($context["site_name"] ?? null), "html", null, true);
        echo "</title>
    <link rel=\"stylesheet\" href=\"/assets/style/auth.css\" />
    <link rel=\"stylesheet\" href=\"/assets/style/loading.css\" />
    <!--      <script src=\"https://www.recaptcha.net/recaptcha/api.js\" async defer></script>
  -->
    <script src=\"/assets/script/jquery.js\"></script>
    <link rel=\"icon\" type=\"img/png\" href=\"/assets/image/icon.png\" sizes=\"192x192\" />
    <style>
      .Sf-Kd {
        position: absolute;
        z-index: 10;
        pointer-events: none;
      }
    </style>
  </head>

  <body>
    <div class=\"main\">
      <p class=\"title\">
        <a href=\"/\" class=\"title\">";
        // line 25
        echo twig_escape_filter($this->env, ($context["site_name"] ?? null), "html", null, true);
        echo "</a>
      </p>
      <div class=\"wrapper\" id=\"main\">
        <p class=\"little-title\">
          <a href=\"/\" class=\"title\">";
        // line 29
        echo twig_escape_filter($this->env, ($context["site_name"] ?? null), "html", null, true);
        echo "</a>
        </p>
        <!-- 加载动画 -->
        <div style=\"margin: auto auto; width: 36px; height:36px\">
          <div class=\"Sf-Kd mspin-medium\" id=\"loading\" style=\"opacity: 0;\">
            <div>
              <div></div>
            </div>
          </div>
        </div>
        <div class=\"login\" id=\"log\" style=\"z-index: 1;opacity: 1;margin-left: 0;\">
          <form onsubmit=\"return false;\">
            <div class=\"input-data\">
              <input type=\"text\" id=\"l-email\" required />
              <div class=\"underline\"></div>
              <label>Email</label>
            </div>
            <div class=\"input-data\" style=\"margin: 25px 0\">
              <input type=\"password\" id=\"l-password\" required />
              <div class=\"underline\"></div>
              <label>密码</label>
            </div>
            <button class=\"btn\" id=\"l-alert\" type=\"submit\" onclick=\"login()\"><span id=\"l-msg\">登录</span></button>
          </form>
          <button class=\"bt forget\" onclick=\"forget_page()\">忘记密码</button>
          <button class=\"bt\" id=\"i\" onclick=\"reg_page()\">注册新账号 <i class=\"icon reg\"></i></button>
          <!-- <div id=\"alert\" style=\"height: 0; padding: 0; border: 0;\"><span id=\"msg\"></span></div> -->
        </div>
        <div class=\"register\" id=\"reg\">
          <p style=\"margin-bottom: 10px; margin-top: -5px\">
            <button class=\"back\" onclick=\"log_page()\"><i class=\"icon back\"></i>返回</button>
          </p>
          <form onsubmit=\"return false;\">
            <div class=\"input-data\">
              <input type=\"text\" id=\"r-email\" required />
              <div class=\"underline\"></div>
              <label>电子邮箱</label>
            </div>
            <div class=\"input-data\" style=\"margin-top: 25px\">
              <input type=\"password\" id=\"r-password\" required />
              <div class=\"underline\"></div>
              <label>密码</label>
            </div>
            <div class=\"input-data\" style=\"margin: 25px 0\">
              <input type=\"password\" id=\"r-repassword\" required />
              <div class=\"underline\"></div>
              <label>重复密码</label>
            </div>
            <div class=\"input-data\" style=\"margin:0\">
              <input type=\"text\" id=\"r-username\" required />
              <div class=\"underline\"></div>
              <label>进服后要使用的玩家名</label>
            </div>
            <button class=\"btn\" id=\"r-alert\" onclick=\"register()\" type=\"submit\"><span id=\"r-msg\">下一步</span></button>
          </form>
        </div>
        <div class=\"captcha\" id=\"captcha\">
          <p class=\"tip\">请在审核群中私信BTL bot，发送“验证码”三个字，它会回复一个验证码，把验证码填在下面就好了。</p>
          <form onsubmit=\"return false;\">
            <div class=\"input-data\">
              <input type=\"text\" id=\"r-code\" required />
              <div class=\"underline\"></div>
              <label>请输入验证码</label>
            </div>
            <button class=\"btn\" id=\"c-alert\" onclick=\"captcha()\" type=\"submit\"><span id=\"c-msg\">下一步</span></button>
          </form>
          <a href=\"/help\" class=\"tip\">为什么需要验证码？</a>
        </div>
        <div class=\"remember\" id=\"remember\">
          <p class=\"tip-title\">保持登录状态？</p>
          <p class=\"tip\">保持登录状态，这样下次就不必重新登录了。</p>
            <button class=\"btn y\" onclick=\"remember(true)\">是</button>
            <button class=\"btn n\" onclick=\"remember(false)\">否</button>
        </div>
        <div class=\"forget\" id=\"forg\">
          <p class=\"tip\">输入你注册时填写的电子邮箱并点击发送</p>
          <form onsubmit=\"return false;\">
            <div class=\"input-data\">
              <input type=\"text\" id=\"f-email\" required />
              <div class=\"underline\"></div>
              <label>电子邮箱</label>
            </div>
            <button type=\"submit\" class=\"btn\">发送</button>
          </form>
          <button class=\"bt\" onclick=\"login_page()\">我又想起来了</button>
        </div>
      </div>
    </div>
    <script src=\"/assets/script/auth.js\"></script>
  </body>
  ";
        // line 120
        echo "  <script src=\"/assets/script/copyright.js\"></script>
</html>
";
    }

    public function getTemplateName()
    {
        return "Y:\\www\\website\\resources\\views/auth.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 120,  74 => 29,  67 => 25,  45 => 6,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\" />
    <title id=\"title\">登录 - {{ site_name }}</title>
    <link rel=\"stylesheet\" href=\"/assets/style/auth.css\" />
    <link rel=\"stylesheet\" href=\"/assets/style/loading.css\" />
    <!--      <script src=\"https://www.recaptcha.net/recaptcha/api.js\" async defer></script>
  -->
    <script src=\"/assets/script/jquery.js\"></script>
    <link rel=\"icon\" type=\"img/png\" href=\"/assets/image/icon.png\" sizes=\"192x192\" />
    <style>
      .Sf-Kd {
        position: absolute;
        z-index: 10;
        pointer-events: none;
      }
    </style>
  </head>

  <body>
    <div class=\"main\">
      <p class=\"title\">
        <a href=\"/\" class=\"title\">{{ site_name }}</a>
      </p>
      <div class=\"wrapper\" id=\"main\">
        <p class=\"little-title\">
          <a href=\"/\" class=\"title\">{{ site_name }}</a>
        </p>
        <!-- 加载动画 -->
        <div style=\"margin: auto auto; width: 36px; height:36px\">
          <div class=\"Sf-Kd mspin-medium\" id=\"loading\" style=\"opacity: 0;\">
            <div>
              <div></div>
            </div>
          </div>
        </div>
        <div class=\"login\" id=\"log\" style=\"z-index: 1;opacity: 1;margin-left: 0;\">
          <form onsubmit=\"return false;\">
            <div class=\"input-data\">
              <input type=\"text\" id=\"l-email\" required />
              <div class=\"underline\"></div>
              <label>Email</label>
            </div>
            <div class=\"input-data\" style=\"margin: 25px 0\">
              <input type=\"password\" id=\"l-password\" required />
              <div class=\"underline\"></div>
              <label>密码</label>
            </div>
            <button class=\"btn\" id=\"l-alert\" type=\"submit\" onclick=\"login()\"><span id=\"l-msg\">登录</span></button>
          </form>
          <button class=\"bt forget\" onclick=\"forget_page()\">忘记密码</button>
          <button class=\"bt\" id=\"i\" onclick=\"reg_page()\">注册新账号 <i class=\"icon reg\"></i></button>
          <!-- <div id=\"alert\" style=\"height: 0; padding: 0; border: 0;\"><span id=\"msg\"></span></div> -->
        </div>
        <div class=\"register\" id=\"reg\">
          <p style=\"margin-bottom: 10px; margin-top: -5px\">
            <button class=\"back\" onclick=\"log_page()\"><i class=\"icon back\"></i>返回</button>
          </p>
          <form onsubmit=\"return false;\">
            <div class=\"input-data\">
              <input type=\"text\" id=\"r-email\" required />
              <div class=\"underline\"></div>
              <label>电子邮箱</label>
            </div>
            <div class=\"input-data\" style=\"margin-top: 25px\">
              <input type=\"password\" id=\"r-password\" required />
              <div class=\"underline\"></div>
              <label>密码</label>
            </div>
            <div class=\"input-data\" style=\"margin: 25px 0\">
              <input type=\"password\" id=\"r-repassword\" required />
              <div class=\"underline\"></div>
              <label>重复密码</label>
            </div>
            <div class=\"input-data\" style=\"margin:0\">
              <input type=\"text\" id=\"r-username\" required />
              <div class=\"underline\"></div>
              <label>进服后要使用的玩家名</label>
            </div>
            <button class=\"btn\" id=\"r-alert\" onclick=\"register()\" type=\"submit\"><span id=\"r-msg\">下一步</span></button>
          </form>
        </div>
        <div class=\"captcha\" id=\"captcha\">
          <p class=\"tip\">请在审核群中私信BTL bot，发送“验证码”三个字，它会回复一个验证码，把验证码填在下面就好了。</p>
          <form onsubmit=\"return false;\">
            <div class=\"input-data\">
              <input type=\"text\" id=\"r-code\" required />
              <div class=\"underline\"></div>
              <label>请输入验证码</label>
            </div>
            <button class=\"btn\" id=\"c-alert\" onclick=\"captcha()\" type=\"submit\"><span id=\"c-msg\">下一步</span></button>
          </form>
          <a href=\"/help\" class=\"tip\">为什么需要验证码？</a>
        </div>
        <div class=\"remember\" id=\"remember\">
          <p class=\"tip-title\">保持登录状态？</p>
          <p class=\"tip\">保持登录状态，这样下次就不必重新登录了。</p>
            <button class=\"btn y\" onclick=\"remember(true)\">是</button>
            <button class=\"btn n\" onclick=\"remember(false)\">否</button>
        </div>
        <div class=\"forget\" id=\"forg\">
          <p class=\"tip\">输入你注册时填写的电子邮箱并点击发送</p>
          <form onsubmit=\"return false;\">
            <div class=\"input-data\">
              <input type=\"text\" id=\"f-email\" required />
              <div class=\"underline\"></div>
              <label>电子邮箱</label>
            </div>
            <button type=\"submit\" class=\"btn\">发送</button>
          </form>
          <button class=\"bt\" onclick=\"login_page()\">我又想起来了</button>
        </div>
      </div>
    </div>
    <script src=\"/assets/script/auth.js\"></script>
  </body>
  {# 严禁删除或修改版权信息，如果删除，作者保留追究其法律责任的权利！ #}
  <script src=\"/assets/script/copyright.js\"></script>
</html>
", "Y:\\www\\website\\resources\\views/auth.twig", "Y:\\www\\website\\resources\\views/auth.twig");
    }
}
