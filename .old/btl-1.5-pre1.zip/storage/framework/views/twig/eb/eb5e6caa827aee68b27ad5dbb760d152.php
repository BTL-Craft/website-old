<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /shared/head.twig */
class __TwigTemplate_a8b90b179bad2f989f37116767e2d807 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        echo "<meta charset=\"utf-8\" />
<meta name=\"viewport\" content=\"width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0\" />
<link rel=\"icon\" type=\"img/png\" href=\"/assets/image/icon.png\" sizes=\"192x192\" />
<link href=\"/assets/style/loading.css\" rel=\"stylesheet\" type=\"text/css\" />
<link href=\"/assets/style/navbar.css\" rel=\"stylesheet\" type=\"text/css\" />
<link href=\"/assets/style/font.css\" rel=\"stylesheet\" type=\"text/css\" />
<script src=\"/assets/script/jquery.js\"></script>
<script src=\"/assets/script/navbar.js\"></script>
<title>";
        // line 9
        echo twig_escape_filter($this->env, ($context["site_name"] ?? null), "html", null, true);
        echo "</title>
";
    }

    public function getTemplateName()
    {
        return "/shared/head.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 9,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<meta charset=\"utf-8\" />
<meta name=\"viewport\" content=\"width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0\" />
<link rel=\"icon\" type=\"img/png\" href=\"/assets/image/icon.png\" sizes=\"192x192\" />
<link href=\"/assets/style/loading.css\" rel=\"stylesheet\" type=\"text/css\" />
<link href=\"/assets/style/navbar.css\" rel=\"stylesheet\" type=\"text/css\" />
<link href=\"/assets/style/font.css\" rel=\"stylesheet\" type=\"text/css\" />
<script src=\"/assets/script/jquery.js\"></script>
<script src=\"/assets/script/navbar.js\"></script>
<title>{{ site_name }}</title>
", "/shared/head.twig", "Y:\\www\\website\\resources\\views//shared/head.twig");
    }
}
